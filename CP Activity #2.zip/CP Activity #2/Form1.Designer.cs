﻿namespace CP_Activity__2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            salesnameBox = new TextBox();
            salesnumberBox = new TextBox();
            unitpricebox = new TextBox();
            sales_Number = new Label();
            salesname_box = new Label();
            quantity_Box = new Label();
            unit_Price = new Label();
            totalbox = new TextBox();
            totalsales_Box = new Label();
            submitbtn = new Button();
            clearbtn = new Button();
            label2 = new Label();
            quantitybox = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(321, 66);
            label1.Name = "label1";
            label1.Size = new Size(473, 32);
            label1.TabIndex = 0;
            label1.Text = "Hi User, Enter a Number To Compute";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // salesnameBox
            // 
            salesnameBox.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            salesnameBox.Location = new Point(12, 185);
            salesnameBox.Name = "salesnameBox";
            salesnameBox.Size = new Size(244, 30);
            salesnameBox.TabIndex = 1;
            // 
            // salesnumberBox
            // 
            salesnumberBox.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            salesnumberBox.Location = new Point(286, 185);
            salesnumberBox.Name = "salesnumberBox";
            salesnumberBox.Size = new Size(244, 30);
            salesnumberBox.TabIndex = 2;
            // 
            // unitpricebox
            // 
            unitpricebox.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            unitpricebox.Location = new Point(863, 185);
            unitpricebox.Name = "unitpricebox";
            unitpricebox.Size = new Size(244, 30);
            unitpricebox.TabIndex = 4;
            // 
            // sales_Number
            // 
            sales_Number.AutoSize = true;
            sales_Number.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            sales_Number.Location = new Point(27, 149);
            sales_Number.Name = "sales_Number";
            sales_Number.Size = new Size(137, 24);
            sales_Number.TabIndex = 5;
            sales_Number.Text = "Sales Number";
            // 
            // salesname_box
            // 
            salesname_box.AutoSize = true;
            salesname_box.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            salesname_box.Location = new Point(337, 149);
            salesname_box.Name = "salesname_box";
            salesname_box.Size = new Size(119, 24);
            salesname_box.TabIndex = 6;
            salesname_box.Text = "Sales Name";
            // 
            // quantity_Box
            // 
            quantity_Box.AutoSize = true;
            quantity_Box.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            quantity_Box.Location = new Point(630, 149);
            quantity_Box.Name = "quantity_Box";
            quantity_Box.Size = new Size(84, 24);
            quantity_Box.TabIndex = 7;
            quantity_Box.Text = "Quantity";
            // 
            // unit_Price
            // 
            unit_Price.AutoSize = true;
            unit_Price.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            unit_Price.Location = new Point(934, 149);
            unit_Price.Name = "unit_Price";
            unit_Price.Size = new Size(97, 24);
            unit_Price.TabIndex = 8;
            unit_Price.Text = "Unit Price";
            // 
            // totalbox
            // 
            totalbox.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            totalbox.Location = new Point(505, 288);
            totalbox.Name = "totalbox";
            totalbox.Size = new Size(244, 30);
            totalbox.TabIndex = 9;
            // 
            // totalsales_Box
            // 
            totalsales_Box.AutoSize = true;
            totalsales_Box.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            totalsales_Box.Location = new Point(371, 294);
            totalsales_Box.Name = "totalsales_Box";
            totalsales_Box.Size = new Size(108, 24);
            totalsales_Box.TabIndex = 10;
            totalsales_Box.Text = "Total Sales";
            // 
            // submitbtn
            // 
            submitbtn.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            submitbtn.Location = new Point(208, 382);
            submitbtn.Name = "submitbtn";
            submitbtn.Size = new Size(309, 55);
            submitbtn.TabIndex = 11;
            submitbtn.Text = "submit";
            submitbtn.UseVisualStyleBackColor = true;
            submitbtn.Click += submitbtn_Click;
            // 
            // clearbtn
            // 
            clearbtn.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            clearbtn.Location = new Point(566, 382);
            clearbtn.Name = "clearbtn";
            clearbtn.Size = new Size(309, 55);
            clearbtn.TabIndex = 12;
            clearbtn.Text = "clear";
            clearbtn.UseVisualStyleBackColor = true;
            clearbtn.Click += clearbtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 479);
            label2.Name = "label2";
            label2.Size = new Size(297, 24);
            label2.TabIndex = 13;
            label2.Text = "Programmer: Wency A. Geraldo";
            // 
            // quantitybox
            // 
            quantitybox.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            quantitybox.Location = new Point(566, 185);
            quantitybox.Name = "quantitybox";
            quantitybox.Size = new Size(244, 30);
            quantitybox.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkGray;
            ClientSize = new Size(1119, 512);
            Controls.Add(label2);
            Controls.Add(clearbtn);
            Controls.Add(submitbtn);
            Controls.Add(totalsales_Box);
            Controls.Add(totalbox);
            Controls.Add(unit_Price);
            Controls.Add(quantity_Box);
            Controls.Add(salesname_box);
            Controls.Add(sales_Number);
            Controls.Add(unitpricebox);
            Controls.Add(quantitybox);
            Controls.Add(salesnumberBox);
            Controls.Add(salesnameBox);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox salesnameBox;
        private TextBox salesnumberBox;
        private TextBox textBox3;
        private TextBox unitpricebox;
        private Label sales_Number;
        private Label salesname_box;
        private Label quantity_Box;
        private Label unit_Price;
        private TextBox totalbox;
        private Label totalsales_Box;
        private Button submitbtn;
        private Button clearbtn;
        private Label label2;
        private TextBox quantitybox;
    }
}
