namespace CP_Activity__2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            int quantity, unitprice, total_sales;
            quantity = Convert.ToInt32(quantitybox.Text);
            unitprice = Convert.ToInt32(unitpricebox.Text);
            total_sales = quantity * unitprice;
            totalbox.Text = Convert.ToString(total_sales);
            MessageBox.Show("The total of " + quantity + " and " + unitprice + " is " + total_sales);
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {

            salesnumberBox.Text = Convert.ToString(" ");
            salesnameBox.Text = Convert.ToString(" ");
            quantitybox.Text = Convert.ToString(" ");
            unitpricebox.Text = Convert.ToString(" ");
            totalbox.Text = Convert.ToString(" ");
        }
    }
}
